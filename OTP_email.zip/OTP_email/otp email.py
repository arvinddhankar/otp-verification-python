import os
import math
import random
import smtplib
digits = "0123456789"
OTP = ""

for i in range (6):
    OTP += digits[math.floor(random.random()*10)]
    
otp = OTP + " is your OTP"
message = otp
s = smtplib.SMTP('smtp.gmail.com', 587)
s.starttls()

emailid = input("Enter your email: ")
s.login("akjatt001@gmail.com", "eezxbfmdiffoaxff")
s.sendmail('akjatt001@gmnail.com','akjatt001@gmail.com',message)

a = input("Enter your OTP >>: ")
if a == OTP:
    print("Verified")
else:
    print("Please Check your OTP again")